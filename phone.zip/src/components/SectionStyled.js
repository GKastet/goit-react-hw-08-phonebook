import styled from 'styled-components';

export const Section = styled.section`
  width: 400px;
  margin: 50px auto 0;
  display: flex;
  flex-direction: column;
`;
